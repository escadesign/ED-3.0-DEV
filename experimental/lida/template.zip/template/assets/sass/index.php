<?php
header('Location: http://theme.dsngrid.com/scar/');
die();